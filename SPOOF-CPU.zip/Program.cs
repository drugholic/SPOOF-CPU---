using System;
using System.Security.Principal;
using Microsoft.Win32;

namespace SPOOF_CPU
{
    internal static class Program
    {
        private const string CpuKeyPath = @"HARDWARE\DESCRIPTION\System\CentralProcessor\0";
        private const string ValueName = "ProcessorNameString";

        private static void Main()
        {
            if (!IsAdministrator())
            {
                Console.WriteLine("Запустите программу от имени администратора.");
                WaitKey();
                return;
            }

            Run();
        }

        private static void Run()
        {
            while (true)
            {
                Console.Clear();
                DrawCurrentCpu();
                DrawMenu();
                if (!HandleChoice()) break;
            }
        }

      

        private static void DrawCurrentCpu()
        {
            string current = ReadCpuName();
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("  Текущее имя в диспетчере задач: ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(string.IsNullOrEmpty(current) ? "(не удалось прочитать)" : current);
            Console.ResetColor();
            Console.WriteLine();
        }

        private static void DrawMenu()
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("  [1] Переименовать процессор");
            Console.WriteLine("  [2] Выход");
            Console.ResetColor();
            Console.WriteLine();
            Console.Write("  Выбор: ");
        }

        private static bool HandleChoice()
        {
            ConsoleKey key = Console.ReadKey(true).Key;
            Console.WriteLine(key == ConsoleKey.D1 ? "1" : key == ConsoleKey.D2 ? "2" : "");

            switch (key)
            {
                case ConsoleKey.D1:
                case ConsoleKey.NumPad1:
                    RenameCpu();
                    return true;
                case ConsoleKey.D2:
                case ConsoleKey.NumPad2:
                    return false;
                default:
                    return true;
            }
        }

        private static void RenameCpu()
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("  Введите новое имя (Enter = отмена): ");
            Console.ResetColor();
            string input = Console.ReadLine()?.Trim();

            if (string.IsNullOrEmpty(input))
            {
                ShowMessage("Отменено.", ConsoleColor.Gray);
                return;
            }

            if (input.Length > 255)
            {
                ShowMessage("Слишком длинное имя (макс. 255 символов).", ConsoleColor.Red);
                return;
            }

            if (WriteCpuName(input))
            {
                ShowMessage("Имя изменено. Закройте и снова откройте диспетчер задач.", ConsoleColor.Green);
            }
            else
            {
                ShowMessage("Не удалось записать в реестр.", ConsoleColor.Red);
            }
        }

        private static void ShowMessage(string text, ConsoleColor color)
        {
            Console.WriteLine();
            Console.ForegroundColor = color;
            Console.WriteLine("  " + text);
            Console.ResetColor();
            Console.WriteLine();
            Console.Write("  Нажмите любую клавишу...");
            Console.ReadKey(true);
        }

        private static string ReadCpuName()
        {
            try
            {
                using (var key = Registry.LocalMachine.OpenSubKey(CpuKeyPath, false))
                {
                    return key?.GetValue(ValueName) as string ?? "";
                }
            }
            catch
            {
                return "";
            }
        }

        private static bool WriteCpuName(string name)
        {
            try
            {
                using (var key = Registry.LocalMachine.OpenSubKey(CpuKeyPath, true))
                {
                    if (key == null) return false;
                    key.SetValue(ValueName, name, RegistryValueKind.String);
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        private static bool IsAdministrator()
        {
            try
            {
                var identity = WindowsIdentity.GetCurrent();
                var principal = new WindowsPrincipal(identity);
                return principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch
            {
                return false;
            }
        }

        private static void WaitKey()
        {
            Console.WriteLine();
            Console.Write("Нажмите любую клавишу...");
            Console.ReadKey(true);
        }
    }
}
